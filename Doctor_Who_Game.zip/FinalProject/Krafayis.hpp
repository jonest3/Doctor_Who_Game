/************************************************
 * *Author:		Taylor Jones (jonest3)	*
 * *Date:		March 15, 2016		*
 * *Description:	Krafayis.hpp 		*
 ************************************************/
#ifndef KRAFAYIS_HPP
#define KRAFAYIS_HPP
#include "Creature.hpp"
#include <iostream>
#include <string>

class Krafayis:public Creature
{
private:

public:
   Krafayis();
};
#endif
