/************************************************
 * *Author:		Taylor Jones (jonest3)	*
 * *Date:		March 15, 2016		*
 * *Description:	VashtaNerada.hpp 	*
 ************************************************/
#ifndef VASHTANERADA_HPP
#define VASHTANERADA_HPP

#include "Creature.hpp"

#include <iostream>
#include <string>

class VashtaNerada:public Creature
{
private:
  
public:
   VashtaNerada();
};
#endif
