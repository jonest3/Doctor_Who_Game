/************************************************
 * *Author:		Taylor Jones (jonest3)	*
 * *Date:		March 15, 2016		*
 * *Description:	WeepingAngels.hpp 	*
 ************************************************/
#ifndef WEEPINGANGELS_HPP
#define WEEPINGANGELS_HPP

#include "Creature.hpp"

#include <iostream>
#include <string>

// Default Constructor
class WeepingAngels:public Creature
{
private:

public:
   WeepingAngels();
};
#endif
