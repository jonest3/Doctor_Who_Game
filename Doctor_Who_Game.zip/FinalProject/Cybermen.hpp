/***************************************************
 * *Author:		Taylor Jones (jonest3)	   *
 * *Date:		March 15, 2016		   *
 * *Description:	Cybermen.hpp - Child class *
 * 			of Creature Class. 	   *
 ***************************************************/
#ifndef CYBERMEN_HPP
#define CYBERMEN_HPP

#include "Creature.hpp"

#include <iostream>
#include <string>

class Cybermen:public Creature
{
private:

public:
   Cybermen();
};
#endif
