/************************************************
 * *Author:		Taylor Jones (jonest3)	*
 * *Date:		March 15, 2016		*
 * *Description:	TheMaster.hpp 		*
 ************************************************/
#ifndef THEMASTER_HPP
#define THEMASTER_HPP

#include "Creature.hpp"

#include <iostream>
#include <string>

class TheMaster:public Creature
{
private:

public:
   TheMaster();
};
#endif
